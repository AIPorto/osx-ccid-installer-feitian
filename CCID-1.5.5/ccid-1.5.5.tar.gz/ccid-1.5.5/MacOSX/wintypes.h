#include <PCSC/wintypes.h>
